var config = {
    map: {
        '*': {
            FancyProductDesigner: 'Laurensmedia_Productdesigner/js/FancyProductDesigner-all.min.js'
        }
    },
    shim: {
        FancyProductDesigner: ['jquery']
    }
};