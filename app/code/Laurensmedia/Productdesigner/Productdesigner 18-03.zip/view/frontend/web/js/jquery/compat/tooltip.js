define(['jquery', 'jquery/ui', 'jquery/ui/widgets/tooltip'], function($) { 'use strict'; return $; });
