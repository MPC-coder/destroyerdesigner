define(['jquery', 'jquery/ui', 'jquery/ui/widgets/button'], function($) { 'use strict'; return $; });
