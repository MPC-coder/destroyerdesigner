define(["jquery", "jquery/ui", "jquery/ui/widgets/selectable"], function($) { "use strict"; });
