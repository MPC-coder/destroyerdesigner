define(['jquery', 'jquery/ui', 'jquery/ui/widgets/menu'], function($) { 'use strict'; return $; });
