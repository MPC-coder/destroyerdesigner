define(["jquery", "jquery/ui", "jquery/ui/widgets/resizable"], function($) { "use strict"; });
