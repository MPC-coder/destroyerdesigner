define(['jquery', 'jquery/ui', 'jquery/ui/widgets/dialog'], function($) { 'use strict'; return $; });
