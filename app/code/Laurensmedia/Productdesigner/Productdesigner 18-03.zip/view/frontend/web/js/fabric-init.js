// Définir une variable fabric globale si elle n'existe pas déjà
window.fabric = window.fabric || { version: '5.2.1' };
define([], function() {
    return window.fabric;
});