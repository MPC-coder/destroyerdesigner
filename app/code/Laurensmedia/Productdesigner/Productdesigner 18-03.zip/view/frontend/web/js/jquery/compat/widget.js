define(["jquery", "jquery/ui", "jquery/ui/widget"], function($) { "use strict"; });
