define(['jquery', 'jquery/ui', 'jquery/ui/widgets/slider'], function($) { 'use strict'; return $; });
