define(['jquery', 'jquery/ui', 'jquery/ui/widgets/sortable'], function($) { 'use strict'; return $; });
