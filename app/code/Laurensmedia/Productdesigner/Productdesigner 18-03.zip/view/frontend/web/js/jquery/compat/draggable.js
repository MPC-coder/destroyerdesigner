define(["jquery", "jquery/ui", "jquery/ui/widgets/draggable"], function($) { "use strict"; });
