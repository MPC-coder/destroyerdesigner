define(['jquery', 'jquery/ui', 'jquery/ui/widgets/droppable'], function($) { 'use strict'; return $; });
