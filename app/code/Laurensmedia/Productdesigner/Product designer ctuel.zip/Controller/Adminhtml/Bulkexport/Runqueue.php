<?php
namespace Laurensmedia\Productdesigner\Controller\Adminhtml\Bulkexport;

use Magento\Backend\App\Action;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderRepository;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Controller\ResultFactory;
use Laurensmedia\Productdesigner\Helper\Tcpdfhelper;
use Laurensmedia\Productdesigner\Model\BulkexportFactory;
use Psr\Log\LoggerInterface;

class Runqueue extends Action
{
    protected BulkexportFactory $bulkexportFactory;
    protected OrderRepository $orderRepository;
    protected Tcpdfhelper $tcpdfHelper;
    protected StoreManagerInterface $storeManager;
    protected File $file;
    protected LoggerInterface $logger;

    public function __construct(
        Action\Context $context,
        BulkexportFactory $bulkexportFactory,
        OrderRepository $orderRepository,
        Tcpdfhelper $tcpdfHelper,
        StoreManagerInterface $storeManager,
        File $file,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->bulkexportFactory = $bulkexportFactory;
        $this->orderRepository = $orderRepository;
        $this->tcpdfHelper = $tcpdfHelper;
        $this->storeManager = $storeManager;
        $this->file = $file;
        $this->logger = $logger;
    }

    public function execute()
    {
        $collection = $this->bulkexportFactory->create()->getCollection()
            ->addFieldToFilter('finished', 0)
            ->setOrder('order_id', 'ASC');

        if (!$collection->getSize()) {
            $this->messageManager->addNoticeMessage(__('No exportable items found.'));
            return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('*/*/index');
        }

        $groupedItems = [];
        foreach ($collection as $item) {
            $storeId = $item->getStoreId();
            $tech = $item->getExportCombining();
            $groupKey = $storeId . '-' . $tech;

            if (!isset($groupedItems[$groupKey])) {
                $groupedItems[$groupKey] = [];
            }
            $groupedItems[$groupKey][] = $item;
        }

        foreach ($groupedItems as $key => $items) {
            [$storeId, $tech] = explode('-', $key);

            try {
                usort($items, fn($a, $b) => $a->getOrderId() <=> $b->getOrderId());

                $firstOrder = $this->orderRepository->get($items[0]->getOrderId());
                $lastOrder = $this->orderRepository->get($items[count($items)-1]->getOrderId());

                $firstOrderId = $firstOrder->getIncrementId();
                $lastOrderId = $lastOrder->getIncrementId();

                $layout = $this->_view->getLayout();
                $block = $layout->createBlock('Laurensmedia\Productdesigner\Block\Index');

                $pdf = $this->tcpdfHelper->getPdfObject($block->get_base_dir(''));
                $pdf->setPrintHeader(false);
                $pdf->setPrintFooter(false);

                foreach ($items as $item) {
                    $pdf->AddPage();
                    $pdf->SetFont('helvetica', '', 10);
                    $pdf->MultiCell(0, 0, "Commande: " . $item->getOrderId() . "\nProduit: " . $item->getProductId(), 0, 'L');
                }

                $datePath = date('Y') . '/' . date('m');
                $random = $firstOrderId . '-' . $lastOrderId;
                $filename = $random . '-' . $tech . '.pdf';
                $relativePath = $datePath . '/' . $filename;
                $absolutePath = $block->get_media_dir('productdesigner/export') . '/' . $relativePath;

                $pdf->Output($absolutePath, 'F');

                foreach ($items as $item) {
                    $item->setFinished(1);
                    $item->setPdfFile($relativePath);
                    $item->save();
                }

                $this->logger->info("[Export PDF] PDF g�n�r� pour $key: $filename");
            } catch (\Exception $e) {
                $this->logger->error("[Export PDF] Erreur pour $key: " . $e->getMessage());
            }
        }

        $this->messageManager->addSuccessMessage(__('PDFs have been generated.'));
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('*/*/index');
    }
}
